# Bill Splitter App 
### Made it with GetX State Management
### it's Responsive

# UI 
##
## 
<img src="https://github.com/Rahul-Sharma-Github/bill_splitter_app/assets/64002004/e199c655-b605-4239-93fc-70c21a3d326a" width="393" height="852">

## 
## 

<img src="https://github.com/Rahul-Sharma-Github/bill_splitter_app/assets/64002004/54fc2982-af40-4307-99f9-59a554cd24fe" width="393" height="852">

## 
## 

<img src="https://github.com/Rahul-Sharma-Github/bill_splitter_app/assets/64002004/92222eff-4018-4ac9-8a85-edfacbc39c90" width="393" height="852">

## 
## 

