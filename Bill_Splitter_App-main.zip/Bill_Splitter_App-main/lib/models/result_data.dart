class ResultData {
  final String equalDivided;
  final String friends;
  final String tax;
  final String tip;

  ResultData(this.equalDivided, this.friends, this.tax, this.tip);
}
